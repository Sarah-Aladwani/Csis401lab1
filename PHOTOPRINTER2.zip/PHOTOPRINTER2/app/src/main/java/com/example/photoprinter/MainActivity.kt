package com.example.photoprinter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        }
    var result: Double = 0.0


    fun radioButtonClick(view: View) {

        val num=editTextNumber2.text.toString().toDouble()
        when (view.id){
             R.id.r1->result=(num*19)/100
            R.id.r2 ->result=(num*49)/100
            R.id.r3-> result=(num*79)/100
        }
            }
    fun click(view: View){
        textR.text = "The order cost is $ "+result

    }

                }


